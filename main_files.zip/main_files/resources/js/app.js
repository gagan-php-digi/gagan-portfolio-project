import './bootstrap';
// import 'laravel-datatables-vite';

import 'https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js';
import 'https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap4.min.js';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
